package com.shneider.electric.api.services;

public class URLBuilder {
	
	public static final String getIFWTokenURL="";
	public static final String crateUserEndPointURL="https://se--devmerge.cs18.my.salesforce.com/services/oauth2/token";
	public static final String salesForceTokenEndPointURL="https://se--uatbfo1.cs18.my.salesforce.com/services/oauth2/token";

}


