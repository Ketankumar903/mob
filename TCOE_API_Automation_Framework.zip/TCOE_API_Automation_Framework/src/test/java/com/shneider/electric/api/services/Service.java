package com.shneider.electric.api.services;

import com.google.gson.Gson;
import com.relevantcodes.extentreports.LogStatus;
import com.schneider.electric.base.Base;
import com.schneider.electric.utility.CommonUtility;
import com.schneider.electric.api.requestpojo.ChangePasswordPojo;
import com.schneider.electric.api.requestpojo.CheckUserPojo;
import com.schneider.electric.api.requestpojo.GetUserDetailsByApplicationPojo;
import com.schneider.electric.api.requestpojo.PasswordRecoveryPojo;
import com.schneider.electric.api.requestpojo.SendInvitationPojo;
import com.schneider.electric.api.requestpojo.SetPasswordPojo;
import com.schneider.electric.api.requestpojo.UpdateUserAILPojo;
import com.schneider.electric.api.requestpojo.UpdateUserProfilePojo;
import com.schneider.electric.api.requestpojo.UserDetails;
import com.schneider.electric.api.requestpojo.UserTrustStatusPojo;


import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.given;

public class Service extends Base{

	String token=null;
	Response response;
	Response checkUserExistResponse;
	Response createUserResponse;
	Response initPwdRecoveryResponse; 
	Response setPasswordResponse;
	Response updateUserResponse;
	Response changePasswordResponse;
	Response getUserResponse;
	Response getUserIDResponse;
	Response getUserProfileResponse;
	Response sendInvitationReponse;
	Response userTrusStatusResponse;
	Response getUserDetailsByAppResponse;
	Response getAllUsersByAppResponse;
	
	
	
	public Response checkUserExist4_0(String emailId, String globalUsers){
		try {
			//1
			token=getIFWToken();
			//2
			String salesforceToken=getSalesForceToken();
			Gson gson=new Gson();
			CheckUserPojo userExistDetails = new CheckUserPojo();
			userExistDetails.setEmail(emailId);
			userExistDetails.setGlobalUsers(globalUsers);
			String jsonCheckUser=gson.toJson(userExistDetails);
			System.out.println(jsonCheckUser);
			
			String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/4.0/users/exist";
			System.out.println("URL: "+URL);
			higlightKeyValueWithColor("END POINT URL",URL,"blue");
			RequestSpecification requestSpec = RestAssured.given();
			requestSpec.header("Content-Type", "application/json");
			requestSpec.header("X-BFO-Authorization",salesforceToken);
			requestSpec.header("Authorization","Bearer "+token);
			requestSpec.header("Accept", "application/json");
			requestSpec.body(jsonCheckUser);
			getHeadersColor(token,salesforceToken);
			checkUserExistResponse=requestSpec.post(URL);
			higlightKeyValueWithColor("Method Type","POST","blue");
			higlightValueWithColor("REQUEST BODY","black");
			higlightValueWithColor(jsonCheckUser,"blue");
		}
		catch (Exception e) {
			
			test.log(LogStatus.FAIL, e.getMessage());
		}
		return checkUserExistResponse;
		
	}

	
	public Response createUserAPI2_0(String username,String password,String salutation,String fName,String mName,String lName,String countryCode,String emailID,String mobile,String langCode,String emailOptIn,String aboutMe,String street,String city,String zip,String stateOrProvinceCode,String county,String pobox,String address,String suffix,String fax,String userContext,String regSource,String currency,String CName,String cStreet,String cCity,String cZip,String companyStateOrProvinceCode,String cPbox,String cCounty,String cCode,String cAdd,String cWebsite,String cLevel1,String cLevel2,String market,String marketSubseg,String marketServ,String eSize,String dept,String headQ,String annualRev,String tin,String jobTitle,String jobFun,String jobDesc,String wPhone)
	{  
	token=getIFWToken();
	String salesforceToken=getSalesForceToken();
	Gson gson=new Gson();
	UserDetails userDetailsPojo2=new UserDetails();
	userDetailsPojo2.setSalutation(salutation);
	userDetailsPojo2.setFirstName(fName);
    userDetailsPojo2.setMiddleName(mName);
    userDetailsPojo2.setLastName(lName);
    userDetailsPojo2.setCountryCode(countryCode);
    userDetailsPojo2.setEmail(emailID);
    userDetailsPojo2.setMobilePhone(mobile);
    userDetailsPojo2.setLanguageCode(langCode);
    userDetailsPojo2.setEmailOptIn(emailOptIn);
    userDetailsPojo2.setAboutMe(aboutMe);
    userDetailsPojo2.setStreet(street);
    userDetailsPojo2.setCity(city);
    userDetailsPojo2.setZipCode(zip);
	userDetailsPojo2.setStateOrProvinceCode(stateOrProvinceCode);
    userDetailsPojo2.setCounty(county);
    userDetailsPojo2.setPOBox(pobox);
    userDetailsPojo2.setAdditionalAddress(address);
    userDetailsPojo2.setSuffix(suffix);
    userDetailsPojo2.setFax(fax);
    userDetailsPojo2.setUserContext(userContext);
    userDetailsPojo2.setRegistrationSource(regSource);
    userDetailsPojo2.setCurrency(currency);
    userDetailsPojo2.setCompanyName(CName);
    userDetailsPojo2.setCompanyStreet(cStreet);
    userDetailsPojo2.setCompanyCity(cCity);
    userDetailsPojo2.setCompanyZipCode(cZip);
    userDetailsPojo2.setCompanyStateOrProvinceCode(companyStateOrProvinceCode);
    userDetailsPojo2.setCompanyPOBox(cPbox);
    userDetailsPojo2.setCompanyCounty(cCounty);
    userDetailsPojo2.setCompanyCountryCode(cCode);
    userDetailsPojo2.setCompanyAdditionalAddress(cAdd);
    userDetailsPojo2.setCompanyWebsite(cWebsite);
    userDetailsPojo2.setClassLevel1(cLevel1);
    userDetailsPojo2.setClassLevel2(cLevel2);
    userDetailsPojo2.setMarketSegment(market);
    userDetailsPojo2.setMarketSubSegment(marketSubseg);
    userDetailsPojo2.setMarketServed(marketServ);
    userDetailsPojo2.setEmployeeSize(eSize);
    userDetailsPojo2.setDepartment(dept);
    userDetailsPojo2.setHeadquarter(headQ);
    userDetailsPojo2.setAnnualRevenue(annualRev);
    userDetailsPojo2.setTaxIdentificationNumber(tin);
    userDetailsPojo2.setJobTitle(jobTitle);
    userDetailsPojo2.setJobFunction(jobFun);
    userDetailsPojo2.setJobDescription(jobDesc);
    userDetailsPojo2.setWorkPhone(wPhone);
    String jsonCreateUser=gson.toJson(userDetailsPojo2);
	System.out.println(jsonCreateUser);
	RequestSpecification requestSpec = RestAssured.given();
	String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/4.0/users";
	higlightKeyValueWithColor("END POINT URL",URL,"blue");
	//Herders
	requestSpec.header("Authorization","Bearer "+token);
	requestSpec.header("X-BFO-Authorization",salesforceToken);
	requestSpec.header("Accept", "application/json");
	requestSpec.header("Content-Type", "application/json");
	getHeadersColor(token,salesforceToken);
	requestSpec.body(jsonCreateUser);
	higlightKeyValueWithColor("Method Type","POST","blue");
	higlightValueWithColor("REQUEST BODY","black");
	higlightValueWithColor(jsonCreateUser,"blue");
	createUserResponse=requestSpec.post(URL);
	return createUserResponse;
	}

	public Response updateUserProfileAPI4(String userAccessToken,String salutation,String fName,String mName,String lName,String countryCode,String emailID,String mobile,String langCode,String emailOptIn,String aboutMe,String street,String city,String zip,String stateOrProvinceCode,String county,String pobox,String address,String suffix,String fax,String profilelastUpdate,String currency,String CName,String cStreet,String cCity,String cZip,String companyStateOrProvinceCode,String cPbox,String cCounty,String cCode,String cAdd,String cWebsite,String cLevel1,String cLevel2,String market,String marketSubseg,String marketServ,String eSize,String dept,String headQ,String annualRev,String tin,String jobTitle,String jobFun,String jobDesc,String wPhone)
	{  

		token=getIFWToken();
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/4.0/users";
		
		higlightKeyValueWithColor("END POINT URL", URL, "blue");
		Gson gson=new Gson();
		UpdateUserProfilePojo updateUser=new UpdateUserProfilePojo();
		updateUser.setSalutation(salutation);
		updateUser.setFirstName(fName);
		updateUser.setMiddleName(mName);
		updateUser.setLastName(lName);
		updateUser.setCountryCode(countryCode);
		updateUser.setEmail(emailID);
		updateUser.setMobilePhone(mobile);
		updateUser.setLanguageCode(langCode);
		updateUser.setEmailOptIn(emailOptIn);
		updateUser.setAboutMe(aboutMe);
        updateUser.setStreet(street);
        updateUser.setCity(city);
        updateUser.setZipCode(zip);
        updateUser.setStateOrProvinceCode(stateOrProvinceCode);
        updateUser.setCounty(county);
        updateUser.setPOBox(pobox);
        updateUser.setAdditionalAddress(address);
        updateUser.setSuffix(suffix);
        updateUser.setFax(fax);
        updateUser.setProfileLastUpdateSource(profilelastUpdate);
        updateUser.setCurrency(currency);
        updateUser.setCompanyName(CName);
        updateUser.setCompanyStreet(cStreet);
        updateUser.setCompanyCity(cCity);
        updateUser.setCompanyZipCode(cZip);
        updateUser.setCompanyStateOrProvinceCode(companyStateOrProvinceCode);
        updateUser.setCompanyPOBox(cPbox);
        updateUser.setCompanyCounty(cCounty);
        updateUser.setCompanyCountryCode(cCode);
        updateUser.setCompanyAdditionalAddress(cAdd);
        updateUser.setCompanyWebsite(cWebsite);
        updateUser.setClassLevel1(cLevel1);
        updateUser.setClassLevel2(cLevel2);
        updateUser.setMarketSegment(market);
        updateUser.setMarketSubSegment(marketSubseg);
        updateUser.setMarketServed(marketServ);
        updateUser.setEmployeeSize(eSize);
        updateUser.setDepartment(dept);
        updateUser.setHeadquarter(headQ);
        updateUser.setAnnualRevenue(annualRev);
        updateUser.setTaxIdentificationNumber(tin);
        updateUser.setJobTitle(jobTitle);
        updateUser.setJobFunction(jobFun);
        updateUser.setJobDescription(jobDesc);
        updateUser.setWorkPhone(wPhone);
		String jsonupdateuser=gson.toJson(updateUser);
		System.out.println(jsonupdateuser);
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Authorization","Bearer "+token);
		requestSpec.header("X-BFO-Authorization",userAccessToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		requestSpec.body(jsonupdateuser);
		getHeadersColor(token, userAccessToken);
		updateUserResponse=requestSpec.put(URL);
		higlightKeyValueWithColor("Method Type","PUT","blue");
		higlightValueWithColor("REQUEST BODY","black");
		higlightValueWithColor(jsonupdateuser,"blue");
		return updateUserResponse;
	}


	public Response changePasswordAPI2(String userAccessToken,String oldPassword,String newPassword,String profileLastUpdateSource)
	{  

		token=getIFWToken();
		Gson gson=new Gson();
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/3.0/password";
		
		higlightKeyValueWithColor("END POINT URL",URL,"blue");
		ChangePasswordPojo changePasswordPojo=new ChangePasswordPojo();
		changePasswordPojo.setOldPassword(oldPassword);
		changePasswordPojo.setNewPassword(newPassword);
		changePasswordPojo.setProfileLastUpdateSource(profileLastUpdateSource);
		String jsonChangePassword=gson.toJson(changePasswordPojo);
		System.out.println(jsonChangePassword);
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Authorization","Bearer "+token);
		requestSpec.header("X-BFO-Authorization",userAccessToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		requestSpec.body(jsonChangePassword);
		getHeadersColor(token, userAccessToken);
		changePasswordResponse=requestSpec.put(URL);
		higlightKeyValueWithColor("Method Type","PUT","blue");
		higlightValueWithColor("REQUEST BODY","black");
		higlightValueWithColor(jsonChangePassword,"blue");
		return changePasswordResponse;
	}




	public String getSalesForceToken()
	{
		String salesForceToken=null;
		try{
			Response r ;			
			r=given().header("key","value").formParam("grant_type","password").formParam("client_id",CONFIG.getProperty("ClientID")).formParam("client_secret",CONFIG.getProperty("ClientSecret")).formParam("username",CONFIG.getProperty("username")).formParam("password",CONFIG.getProperty("password")).when()
					.post(CONFIG.getProperty("Salesforce_Token_URL"));
			//test.log(LogStatus.INFO, r.asString());
			salesForceToken=r.body().jsonPath().getString("access_token");
			System.out.println(salesForceToken);
			//test.log(LogStatus.INFO, "Salesforce Token is "+salesForceToken);
		}
		catch(Exception ex)
		{   System.out.println(ex.getMessage());
			ex.printStackTrace();
			test.log(LogStatus.FAIL, ex.getMessage());
		}

		return salesForceToken;
	}

	//Get IFW Token	
		public String getIFWToken()
		{ 
			String  IFW_Access_Token=null;
			try{
				String baseURL="https://api-test.schneider-electric.com/token?client_id="+CONFIG.getProperty("IFW_CLIENT_ID")+"&client_secret="+CONFIG.getProperty("IFW_CLIENT_SECRET")+"&grant_type=client_credentials";
				System.out.println(baseURL);
				Response r ;
				r=given().when().post(baseURL);
				int responseCode=r.getStatusCode();
				String responseBody=r.getBody().asString();
				System.out.println(responseCode);
				System.out.println(responseBody); 

				IFW_Access_Token=r.body().jsonPath().getString("access_token");
				System.out.println(IFW_Access_Token);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}

			return IFW_Access_Token;
		}

	
	public String getSalesForceToken(String clientID,String clientSecret,String username,String password)
	{
		String salesForceToken=null;
		try{
			Response r ;
			r=given().headers("Key","Value").formParam("grant_type","password").formParam("client_id",clientID).formParam("client_secret",clientSecret).formParam("username",username).formParam("password",password).when()
					.post(URLBuilder.salesForceTokenEndPointURL);
			//test.log(LogStatus.INFO, r.asString());
			salesForceToken=r.body().jsonPath().getString("access_token");
			System.out.println(salesForceToken);
			//test.log(LogStatus.INFO, "Salesforce Token is "+salesForceToken);
		}
		catch(Exception ex)
		{
			//test.log(LogStatus.FAIL, ex.getMessage());
		}

		return salesForceToken;
	}

	public Response initPasswordRecovery2_0(String clientID,String clientSecret,String username,String password,String email,String profileUpadateSource)
	{
		Gson gson=new Gson();
		String token=getIFWToken();
		System.out.println(token+"IFW Token");
		String salesforceToken=getSalesForceToken();
		System.out.println(salesforceToken+"Sales force token");
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/3.0/password/resetrequest";
		
		higlightKeyValueWithColor("END POINT URL", URL, "blue");
		PasswordRecoveryPojo passwordRecoveryPojo=new PasswordRecoveryPojo();
		passwordRecoveryPojo.setEmail(email);
		passwordRecoveryPojo.setProfileLastUpdateSource(profileUpadateSource);
		String jsonPwdRecovery=gson.toJson(passwordRecoveryPojo);
		System.out.println(jsonPwdRecovery+"passwordrecovery json");
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Authorization","Bearer "+token);
		requestSpec.header("X-BFO-Authorization",salesforceToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		requestSpec.body(jsonPwdRecovery);
		getHeadersColor(token, salesforceToken);
		initPwdRecoveryResponse=requestSpec.post(URL);
		higlightKeyValueWithColor("Method Type", "POST", "blue");
		higlightValueWithColor("REQUEST BODY","black");
		higlightValueWithColor(jsonPwdRecovery,"blue");
		return initPwdRecoveryResponse;
	
	}
	

	
	
	public Response setPassword2_0(String clientID,String clientSecret,String username,String password,String userID,String setNewPassword,String profileLastUpadateSource,String resetToken)
	{
		Gson gson=new Gson();
		String token=getIFWToken();
		System.out.println(token+"IFW Token");
		String salesforceToken=getSalesForceToken();
		System.out.println(salesforceToken+"Sales force token");
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/3.0/password";
		
		higlightKeyValueWithColor("END POINT URL", URL, "blue");
		SetPasswordPojo setpasswordpojo=new SetPasswordPojo();
		setpasswordpojo.setUserId(userID);
		setpasswordpojo.setPassword(setNewPassword);
		setpasswordpojo.setProfileLastUpdateSource(profileLastUpadateSource);
		setpasswordpojo.setToken(resetToken);
		String jsonSetPassword=gson.toJson(setpasswordpojo);
		System.out.println(jsonSetPassword+"json");
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Authorization","Bearer "+token);
		requestSpec.header("X-BFO-Authorization",salesforceToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		requestSpec.body(jsonSetPassword);
		getHeadersColor(token, salesforceToken);
		setPasswordResponse=requestSpec.post(URL);
		higlightKeyValueWithColor("METHOD TYPE", "POST", "blue");
		System.out.println(setPasswordResponse.asString());
        higlightValueWithColor("REQUEST BODY", "black");
        higlightValueWithColor(jsonSetPassword, "blue");
		return setPasswordResponse;
	}


	public Response setPassword2_0_withFedId(String clientID,String clientSecret,String username,String password,String fedId,String setNewPassword,String profileLastUpadateSource,String resetToken)
	{
		Gson gson=new Gson();
		String token=getIFWToken();
		System.out.println(token+"IFW Token");
		String salesforceToken=getSalesForceToken();
		System.out.println(salesforceToken+"Sales force token");
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/3.0/password";
		higlightKeyValueWithColor("END POINT URL", URL, "blue");
		SetPasswordPojo setpasswordpojo=new SetPasswordPojo();
		setpasswordpojo.setFederatedId(fedId);
		setpasswordpojo.setPassword(setNewPassword);
		setpasswordpojo.setProfileLastUpdateSource(profileLastUpadateSource);
		setpasswordpojo.setToken(resetToken);
		String jsonSetPassword=gson.toJson(setpasswordpojo);
		System.out.println(jsonSetPassword+"json");
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Authorization","Bearer "+token);
		requestSpec.header("X-BFO-Authorization",salesforceToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		getHeadersColor(token, salesforceToken);
		requestSpec.body(jsonSetPassword);
		setPasswordResponse=requestSpec.post(URL);
		higlightKeyValueWithColor("METHOD TYPE", "POST", "blue");
		System.out.println(setPasswordResponse.asString());
		 higlightValueWithColor("REQUEST BODY", "black");
	     higlightValueWithColor(jsonSetPassword, "blue");
		return setPasswordResponse;

	}


	

	

	public Response updateUserAilAPI4_0(String userID,String aclType,String acl,String operations,String profileLastUpdateSource,String type){

		Gson gson=new Gson();
		String token=getIFWToken();
		System.out.println(token+"IFW Token");
		String salesforceToken=getSalesForceToken();
		System.out.println(salesforceToken+"Sales force token");
		UpdateUserAILPojo updateUserAILPojo=new UpdateUserAILPojo();
		updateUserAILPojo.setAclType(aclType);
		updateUserAILPojo.setAcl(acl);
		updateUserAILPojo.setOperation(operations);
		updateUserAILPojo.setProfileLastUpdateSource(profileLastUpdateSource);
		String jsonUpdateUserAIL=gson.toJson(updateUserAILPojo);
		
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Authorization","Bearer "+token);
		requestSpec.header("X-BFO-Authorization",salesforceToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		requestSpec.body(jsonUpdateUserAIL);
		String URL="";
		if(type.equals("UserID"))
		{
			URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/4.0/ail/"+userID;
			higlightKeyValueWithColor("END POINT URL", URL,"blue");
		}
		if(type.equals("FedID")){
			URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/4.0/ail/"+userID;
			higlightKeyValueWithColor("END POINT URL", URL,"blue");
		}
		getHeadersColor(token, salesforceToken);
		setPasswordResponse=requestSpec.put(URL);
		higlightKeyValueWithColor("Method Type","PUT","blue");
		higlightValueWithColor("REQUEST BODY","black");
		higlightValueWithColor(jsonUpdateUserAIL,"blue");
		return setPasswordResponse;
	}

	
	
	
	
	public String getUserID(String emailID){

		//1
		String salesforceToken=getSalesForceToken();
		System.out.println(salesforceToken+"Salesforce token");
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Content-Type", "application/json");
		requestSpec.header("Authorization","Bearer "+salesforceToken);
		requestSpec.header("Accept", "application/json");
		//it may change in UAT
		String url="https://se--uatbfo.cs65.my.salesforce.com/services/data/v37.0/query?q=SELECT Id FROM User WHERE Email='"+emailID+"'";
//		String url="https://se--preprodbfo.cs18.my.salesforce.com/services/data/v37.0/query?q=SELECT Id FROM User WHERE Email='"+emailID+"'"; 
		System.out.println("URL: "+url);
		getUserIDResponse=requestSpec.get(url);
		String text=getUserIDResponse.body().jsonPath().getString("records");
		System.out.println(text);
		String splittext[]=text.split(",");
		String trimtext=splittext[2].trim().replace("]]","");
		String userID[]=trimtext.split(":");
		System.out.println("Status Code: "+getUserIDResponse.getStatusCode());
		System.out.println(getUserIDResponse.asString());
		System.out.println(userID[1]);
		return userID[1];
	}

	public String getFedID(String emailID,String clientID,String clientSecret,String username,String password ){

		//1
		String salesforceToken=getSalesForceToken();
		System.out.println(salesforceToken+"Salesforce token");
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Content-Type", "application/json");
		requestSpec.header("Authorization","Bearer "+salesforceToken);
		requestSpec.header("Accept", "application/json");
		//it may change in UAT
		String url="https://se--uatbfo.cs665.my.salesforce.com/services/data/v37.0/query?q=SELECT Id FROM User WHERE Email='"+emailID+"'";
		System.out.println("URL: "+url);
		getUserIDResponse=requestSpec.get(url);
		String text=getUserIDResponse.body().jsonPath().getString("records");
		String splittext[]=text.split(",");
		String trimtext=splittext[2].trim().replace("]]","");
		String userID[]=trimtext.split(":");
		System.out.println("Status Code: "+getUserIDResponse.getStatusCode());
		System.out.println(getUserIDResponse.asString());
		System.out.println(userID[1]);
		return userID[1];
	}

	
	

	
	public Response getUserProfile4_0(String emailID,String type,String userSession)
	{
		String ifwToken=getIFWToken();
		String userID_FedID="";
		RequestSpecification requestSpec = RestAssured.given();
				
			if(type.equals("UserID")){
			String salesforceToken=getSalesForceToken();	
			userID_FedID=getUserID(emailID);
			String url=CONFIG.getProperty("Base_URL")+"/rest/idms/user/4.0/users/"+userID_FedID;
			higlightKeyValueWithColor("END POINT URL",url,"blue");
			requestSpec.header("Authorization","Bearer "+ifwToken);
			requestSpec.header("X-BFO-Authorization",salesforceToken);
			requestSpec.header("Accept", "application/json");
			requestSpec.header("Content-Type", "application/json");	
			getHeadersColor(ifwToken,salesforceToken);
			getUserProfileResponse=requestSpec.get(url);
			higlightKeyValueWithColor("Method Type","GET","blue");
			System.out.println(getUserProfileResponse.asString());
			System.out.println("Status Code: "+getUserProfileResponse.getStatusCode());
			}
			if(type.equals("FedID")){
				String salesforceToken=getSalesForceToken();
				userID_FedID=getFederationID(emailID);	
				String url=CONFIG.getProperty("Base_URL")+"/rest/idms/user/3.0/users?UIMSFederatedId="+userID_FedID;
				higlightKeyValueWithColor("END POINT URL",url,"blue");
				requestSpec.header("Authorization","Bearer "+ifwToken);
				requestSpec.header("X-BFO-Authorization",salesforceToken);
				requestSpec.header("Accept", "application/json");
				requestSpec.header("Content-Type", "application/json");	
				getHeadersColor(ifwToken,salesforceToken);
				getUserProfileResponse=requestSpec.get(url);
				higlightKeyValueWithColor("Method Type","GET","blue");
				System.out.println(getUserProfileResponse.asString());
				System.out.println("Status Code: "+getUserProfileResponse.getStatusCode());
				}
			if(type.equals("userSession"))
			{
				String url=CONFIG.getProperty("Base_URL")+"/rest/idms/user/3.0/users";
				higlightKeyValueWithColor("END POINT URL",url,"blue");
				requestSpec.header("Authorization","Bearer "+ifwToken);
				requestSpec.header("X-BFO-Authorization",userSession);
				requestSpec.header("Accept", "application/json");
				requestSpec.header("Content-Type", "application/json");
				getHeadersColor(ifwToken,userSession);
				getUserProfileResponse=requestSpec.get(url);
				higlightKeyValueWithColor("Method Type","GET","blue");
			}
			
			return getUserProfileResponse;	
	}


	public String getFederationID(String emailID){

		//1
		String salesforceToken=getSalesForceToken();
		System.out.println(salesforceToken+"Salesforce token");
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Content-Type", "application/json");
		requestSpec.header("Authorization","Bearer "+salesforceToken);
		requestSpec.header("Accept", "application/json");
		String url="https://se--uatbfo.cs65.my.salesforce.com/services/data/v37.0/query?q=SELECT id,federationidentifier FROM User WHERE Email='"+emailID+"'";
//		String url="https://se--preprodbfo.cs18.my.salesforce.com/services/data/v37.0/query?q=SELECT id,federationidentifier FROM User WHERE Email='"+emailID+"'";
		System.out.println("URL: "+url);
		getUserIDResponse=requestSpec.get(url);
		System.out.println(getUserIDResponse.asString());
		String text=getUserIDResponse.asString();
		String splittext[]=text.split(",");
		String test="";
		for(int i=0;i<splittext.length;i++)
		{
			System.out.println(splittext[i]);
			if(splittext[i].contains("FederationIdentifier"))
			{
				test=CommonUtility.after(splittext[i],"\"FederationIdentifier\":\"");
				break;
			}
		}

		test=test.replace("\"}]}", "");
		System.out.println(test+" Fed ID");
		return test;
	}


	public Response sendInvitationAPI(String clientID,String clientSecret,String username,String password,String newEmail,String inviteID,String redirectUrl)
	{
		Gson gson=new Gson();
		String token=getIFWToken();
		System.out.println(token+"IFW Token");
		String salesforceToken=getSalesForceToken();
		SendInvitationPojo sendInvitationPojo=new SendInvitationPojo();
		sendInvitationPojo.setEmail(newEmail);
		sendInvitationPojo.setInvitationId(inviteID);
		sendInvitationPojo.setRedirectUrl(redirectUrl);
		String jsonSendInvitation=gson.toJson(sendInvitationPojo);
		System.out.println(jsonSendInvitation+"json");
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Authorization","Bearer "+token);
		requestSpec.header("X-BFO-Authorization",salesforceToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		requestSpec.body(jsonSendInvitation);
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/1.0/invitation";
		sendInvitationReponse=requestSpec.post(URL);
		System.out.println(sendInvitationReponse.asString());
		return sendInvitationReponse;
	}
	

	public Response sendInvitationAPI4(String newEmail,String inviteID,String redirectUrl)
	{
		Gson gson=new Gson();
		String token=getIFWToken();
		System.out.println(token+"IFW Token");
		String salesforceToken=getSalesForceToken();
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/4.0/invitation";
		higlightKeyValueWithColor("END POINT URL",URL,"blue");
		SendInvitationPojo sendInvitationPojo=new SendInvitationPojo();
		sendInvitationPojo.setEmail(newEmail);
		sendInvitationPojo.setInvitationId(inviteID);
		sendInvitationPojo.setRedirectUrl(redirectUrl);
		String jsonSendInvitation=gson.toJson(sendInvitationPojo);
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.header("Authorization","Bearer "+token);
		requestSpec.header("X-BFO-Authorization",salesforceToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		getHeadersColor(token,salesforceToken);
		requestSpec.body(jsonSendInvitation);
		higlightValueWithColor("REQUEST BODY","black");
		higlightValueWithColor(jsonSendInvitation,"blue");
		sendInvitationReponse=requestSpec.post(URL);
		higlightKeyValueWithColor("Method Type","POST","blue");
		return sendInvitationReponse;
	}

	public Response userTrustStatusAPI4(String emailID, String trustedAdminId,String newTrustedStatus,String profileUpdateSource,String rejectionReason,String rejectionComments)
	{
		Gson gson=new Gson();
		String ifw_Token=getIFWToken();
		String salesforceToken=getSalesForceToken();
		String userID=getFederationID(emailID);
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/4.0/users/"+userID+"/truststatus";
		System.out.println(URL);
		higlightKeyValueWithColor("END POINT URL",URL,"blue");
		UserTrustStatusPojo userTrust=new UserTrustStatusPojo();
		userTrust.setTrustedAdminId(trustedAdminId);
		userTrust.setNewTrustedStatus(newTrustedStatus);
		userTrust.setProfileUpdateSource(profileUpdateSource);
		userTrust.setRejectionReason(rejectionReason);
		userTrust.setRejectionComments(rejectionComments);
		String jsonUserTrust=gson.toJson(userTrust);
		RequestSpecification requestSpec=RestAssured.given();
		requestSpec.header("Authorization","Bearer "+ifw_Token);
		requestSpec.header("X-BFO-Authorization",salesforceToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		getHeadersColor(token,salesforceToken);
		requestSpec.body(jsonUserTrust);
		higlightValueWithColor("REQUEST BODY","black");
		higlightValueWithColor(jsonUserTrust,"blue");
		userTrusStatusResponse=requestSpec.put(URL);
		return userTrusStatusResponse;
	}
	
	
	public Response getUserDetailsByApplicationAPI(String emailID,String appHash)
	{
//		Gson gson=new Gson();
		String ifw_Token=getIFWToken();
		String salesforceToken=getSalesForceToken();
		
		Gson gson=new Gson();
		GetUserDetailsByApplicationPojo getUserByApplication = new GetUserDetailsByApplicationPojo();
		getUserByApplication.setAppHash(appHash);
		getUserByApplication.setEmail(emailID);
		String jsonGetUserByApplication=gson.toJson(getUserByApplication);
		System.out.println(jsonGetUserByApplication);
		
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/4.0/appusers";
		higlightKeyValueWithColor("END POINT URL",URL,"blue");
		RequestSpecification requestSpec=RestAssured.given();
		requestSpec.header("Authorization","Bearer "+ifw_Token);
		requestSpec.header("X-BFO-Authorization",salesforceToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		
		getHeadersColor(ifw_Token,salesforceToken);
		
		requestSpec.body(jsonGetUserByApplication);
		higlightKeyValueWithColor("Method Type","GET","blue");
		getUserDetailsByAppResponse=requestSpec.post(URL);
		System.out.println(requestSpec.log().all());
		String res=getUserDetailsByAppResponse.asString();
		System.out.println(res);
		return getUserDetailsByAppResponse;
	}
	
	
	
	public Response getAllUsersByApplicationAPI(String emailID,String clientID,String clientSecret,String username,String password,String appHash,String stardate,String enddate )
	{
//		Gson gson=new Gson();
		String ifw_Token=getIFWToken();
		String salesforceToken=getSalesForceToken();
		RequestSpecification requestSpec=RestAssured.given();
		String URL=CONFIG.getProperty("Base_URL")+"/rest/idms/user/3.0/appusers/list?appHash="+appHash+"&startDate="+stardate+"&endDate="+enddate;
		higlightKeyValueWithColor("END POINT URL",URL,"blue");
		requestSpec.header("Authorization","Bearer "+ifw_Token);
		requestSpec.header("X-BFO-Authorization",salesforceToken);
		requestSpec.header("Accept", "application/json");
		requestSpec.header("Content-Type", "application/json");
		getHeadersColor(ifw_Token,salesforceToken);
		higlightKeyValueWithColor("Method Type","GET","blue");
		getAllUsersByAppResponse=requestSpec.get(URL);
		return getAllUsersByAppResponse;
	}
	
	public static void getHeadersColor(String ifw_token,String salesforceToken)
	{  try{
		test.log(LogStatus.INFO,"<span style='font-weight:bold;color:black;'>HEADERS</span>");
		test.log(LogStatus.INFO,"<span style='font-weight:bold;color:black;'>Authorization: </span>"+"<span style='font-weight:bold;color:blue;'>Bearer"+" "+ifw_token+"</span>");
		test.log(LogStatus.INFO,"<span style='font-weight:bold;color:black;'>X-BFO-Authorization: </span>"+"<span style='font-weight:bold;color:blue;'>"+salesforceToken+"</span>");
		test.log(LogStatus.INFO,"<span style='font-weight:bold;color:black;'>Accept: </span>"+"<span style='font-weight:bold;color:blue;'>"+"application/json"+"</span>");
		test.log(LogStatus.INFO,"<span style='font-weight:bold;color:black;'>Content Type: </span>"+"<span style='font-weight:bold;color:blue;'>"+"application/json"+"</span>");
	  }
	   catch(Exception ex)
	{
		   test.log(LogStatus.INFO,ex.getMessage());
	}
	}
	
	public void higlightKeyValueWithColor(String key,String value,String color)
	{
		test.log(LogStatus.INFO,"<span style='font-weight:bold;color:black;'>"+key+": "+"</span>"+"<span style='font-weight:bold;color:"+color+";'>"+value+"</span>");
		
	}
	
	public void higlightValueWithColor(String value,String color)
	{
		test.log(LogStatus.INFO,"<span style='font-weight:bold;color:"+color+";'>"+value+"</span>");
	}
	
	public void higlightSuccessCodeWithColor(String key,int value,String color)
	{
		test.log(LogStatus.PASS,"<span style='font-weight:bold;color:black;'>"+key+": "+"</span>"+"<span style='font-weight:bold;color:"+color+";'>"+value+"</span>");
		
	}
	
	public void higlightfailureCodeWithColor(String key,int value,String color)
	{
		test.log(LogStatus.FAIL,"<span style='font-weight:bold;color:black;'>"+key+": "+"</span>"+"<span style='font-weight:bold;color:"+color+";'>"+value+"</span>");
		
	}
	
	
	
	
	
}
