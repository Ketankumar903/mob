package com.schneider.electric.api.tests;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.schneider.electric.base.Base;
import com.schneider.electric.utility.TestUtil;
import com.shneider.electric.api.services.Service;

import io.restassured.response.Response;

public class CheckUserExistAPI4 extends Base{
	
	//runmode one dimensional array for test data set
		String runmodes[]=null;
		//initial counter is negative
		static int count=-1;
		//skip variable set to false into test data sheet
		static boolean skip=false;
		//pass variable set to false into test data sheet
		static boolean pass=false;
		//fail variable set to false into test data sheet
		static boolean fail=false;
		//set result overall in test case sheet
		static boolean isTestPass=true;
		Service service;
		@BeforeTest
		public void checkTestSkip()
		{  
			if(!TestUtil.isTestCaseRunnable(suiteBxls,this.getClass().getSimpleName()))
			{
				test=report.startTest(this.getClass().getSimpleName());
				test.log(LogStatus.SKIP,this.getClass().getSimpleName()+" Skipped.");
				skip=true;
				reportTestResult();
				throw new SkipException("Test case skipped.");
			}
			//load the runmodes of the tests
			runmodes=TestUtil.getDataSetRunmodes(suiteBxls, this.getClass().getSimpleName());

		}
		@Test(dataProvider="getTestData")
		public void checkUserExistAPI(String emailID, String globalUsers)
		{
			// test the runmode of current dataset
					count++;
					if(!runmodes[count].equalsIgnoreCase("Y")){
						test=report.startTest(this.getClass().getSimpleName());
						test.log(LogStatus.SKIP,this.getClass().getSimpleName()+" Skipped.");
						//reportTestResult();
						skip=true;
						throw new SkipException("Runmode for test set data set to no "+count);
					}
			//1. Start Test
			test=report.startTest(this.getClass().getSimpleName());
			System.out.println("=============================");
			System.out.println("Check user Exist API");
			System.out.println("=============================");
			
			//Create an Object of service class to access API's
			service=new Service();
			//Get IFW Token
		   // String token=service.getIFWToken();
			//test.log(LogStatus.INFO, token);
			//get response from checkUserexist API
			Response checkUserExistResponse=service.checkUserExist4_0(emailID, globalUsers);

			System.out.println(checkUserExistResponse.asString());

			service.higlightValueWithColor("RESPONSE","black");
			//verify status code
			if(checkUserExistResponse.getStatusCode()==200){
				service.higlightSuccessCodeWithColor("Status Code",checkUserExistResponse.getStatusCode(),"green");
				service.higlightValueWithColor("User exists","green");
			}
			else{
				service.higlightfailureCodeWithColor("Status Code",checkUserExistResponse.getStatusCode(),"red");
				service.higlightValueWithColor("User does not exists","red");
			}
		}
		
		//Parameterize test case
		@DataProvider
		public Object[][] getTestData()
		{
		  return TestUtil.getData(suiteBxls, this.getClass().getSimpleName());
		}
		
		@AfterMethod
		public void reportDataSetResult()
		{
			if(skip)
				TestUtil.reportDataSetResult(suiteBxls, this.getClass().getSimpleName(),count+2,"SKIP");
			else if(fail){
				isTestPass=false;
				TestUtil.reportDataSetResult(suiteBxls, this.getClass().getSimpleName(),count+2,"FAIL");
			}
			else
				TestUtil.reportDataSetResult(suiteBxls, this.getClass().getSimpleName(),count+2,"PASS");
			skip=false;
			fail=false;
			report.endTest(test);
			report.flush();

		}



		@AfterTest
		public void reportTestResult()
		{
			if(isTestPass)
			{
				TestUtil.reportDataSetResult(suiteBxls,"Test Cases",TestUtil.getRowNum(suiteBxls,this.getClass().getSimpleName()),"PASS");
			}
			else
			{
				TestUtil.reportDataSetResult(suiteBxls,"Test Cases",TestUtil.getRowNum(suiteBxls,this.getClass().getSimpleName()),"FAIL");
			}
			if(skip&&isTestPass)
			{
				TestUtil.reportDataSetResult(suiteBxls,"Test Cases",TestUtil.getRowNum(suiteBxls,this.getClass().getSimpleName()),"SKIP");
			}

		}


}
