package com.schneider.electric.api.tests;

import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.schneider.electric.base.Base;
import com.schneider.electric.utility.TestUtil;
import com.shneider.electric.api.services.Service;

import io.restassured.response.Response;

public class CreateUserAPI4 extends Base{
	
	//runmode one dimensional array for test data set
		String runmodes[]=null;
		//initial counter is negative
		static int count=-1;
		//skip variable set to false into test data sheet
		static boolean skip=false;
		//pass variable set to false into test data sheet
		static boolean pass=false;
		//fail variable set to false into test data sheet
		static boolean fail=false;
		//set result overall in test case sheet
		static boolean isTestPass=true;
		com.shneider.electric.api.services.Service service;
		@BeforeTest
		public void checkTestSkip()
		{  
			if(!com.schneider.electric.utility.TestUtil.isTestCaseRunnable(suiteBxls,this.getClass().getSimpleName()))
			{
				test=report.startTest(this.getClass().getSimpleName());
				test.log(LogStatus.SKIP,this.getClass().getSimpleName()+" Skipped.");
				skip=true;
				reportTestResult();
				throw new SkipException("Test case skipped.");
			}
			//load the runmodes of the tests
			runmodes=com.schneider.electric.utility.TestUtil.getDataSetRunmodes(suiteBxls, this.getClass().getSimpleName());

		}
		
		@Test(dataProvider="getTestData")
		public void createUserAPI(String username,String password,String salutation,String fName,String mName,String lName,String countryCode,String emailID,String mobile,String langCode,String emailOptIn,String aboutMe,String street,String city,String zip,String stateOrProvinceCode,String county,String pobox,String address,String suffix,String fax,String userContext,String regSource,String currency,String CName,String cStreet,String cCity,String cZip,String companyStateOrProvinceCode,String cPbox,String cCounty,String cCode,String cAdd,String cWebsite,String cLevel1,String cLevel2,String market,String marketSubseg,String marketServ,String eSize,String dept,String headQ,String annualRev,String tin,String jobTitle,String jobFun,String jobDesc,String wPhone)
		{
			// test the runmode of current dataset
			count++;
			if(!runmodes[count].equalsIgnoreCase("Y")){
				test=report.startTest(this.getClass().getSimpleName());
				test.log(LogStatus.SKIP,this.getClass().getSimpleName()+" Skipped.");
				//reportTestResult();
				skip=true;
				throw new SkipException("Runmode for test set data set to no "+count);
			}

			//1. Start Test
			test=report.startTest(this.getClass().getSimpleName());			
			System.out.println("=============================");
			System.out.println("Create user API");
			System.out.println("=============================");
			
			//Create an Object of service class to access API's
			service=new Service();
			//get response from checkUserexist API
			Response userResponse=service.createUserAPI2_0(username,password,salutation,fName,mName,lName,countryCode,emailID,mobile,langCode,emailOptIn,aboutMe,street,city,zip,stateOrProvinceCode,county,pobox,address,suffix,fax,userContext,regSource,currency,CName,cStreet,cCity,cZip,companyStateOrProvinceCode,cPbox,cCounty,cCode,cAdd,cWebsite,cLevel1,cLevel2,market,marketSubseg,marketServ,eSize,dept,headQ,annualRev,tin,jobTitle,jobFun,jobDesc,wPhone);
			
			//verify status code
			if(userResponse.getStatusCode()==200){
				
				service.higlightSuccessCodeWithColor("Status Code",userResponse.getStatusCode(),"green");
				service.higlightValueWithColor(userResponse.asString(),"green");
				service.higlightValueWithColor("User Created Successfully.","green");
				String userID=userResponse.body().jsonPath().getString("userId");
				service.higlightKeyValueWithColor("User ID", userID,"green");
			}
			else{
				service.higlightfailureCodeWithColor("Status Code",userResponse.getStatusCode(),"red");
				String message=userResponse.body().jsonPath().getString("message");
				service.higlightValueWithColor(userResponse.asString(),"red");
				service.higlightValueWithColor(message,"red");
			}
		}
		
		//Parameterize test case
		@DataProvider
		public Object[][] getTestData()
		{
		  return TestUtil.getData(suiteBxls, this.getClass().getSimpleName());
		}
		
		@AfterMethod
		public void reportDataSetResult()
		{
			if(skip)
				TestUtil.reportDataSetResult(suiteBxls, this.getClass().getSimpleName(),count+2,"SKIP");
			else if(fail){
				isTestPass=false;
				TestUtil.reportDataSetResult(suiteBxls, this.getClass().getSimpleName(),count+2,"FAIL");
			}
			else
				TestUtil.reportDataSetResult(suiteBxls, this.getClass().getSimpleName(),count+2,"PASS");
			skip=false;
			fail=false;
			report.endTest(test);
			report.flush();

		}

		@AfterTest
		public void reportTestResult()
		{
			if(isTestPass)
			{
				TestUtil.reportDataSetResult(suiteBxls,"Test Cases",TestUtil.getRowNum(suiteBxls,this.getClass().getSimpleName()),"PASS");
			}
			else
			{
				TestUtil.reportDataSetResult(suiteBxls,"Test Cases",TestUtil.getRowNum(suiteBxls,this.getClass().getSimpleName()),"FAIL");
			}
			if(skip&&isTestPass)
			{
				TestUtil.reportDataSetResult(suiteBxls,"Test Cases",TestUtil.getRowNum(suiteBxls,this.getClass().getSimpleName()),"SKIP");
			}

		}

}
