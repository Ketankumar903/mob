package com.schneider.electric.api.requestpojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CheckUserPojo {
	
	@SerializedName("email")
	@Expose
	private String email;
	
	@SerializedName("withGlobalUsers")
	@Expose
	private boolean GlobalUsers;

	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean getGlobalUsers() {
		return GlobalUsers;
	}

	public void setGlobalUsers(String globalUsers) {
		GlobalUsers = Boolean.parseBoolean(globalUsers);
	}
	
	
}
