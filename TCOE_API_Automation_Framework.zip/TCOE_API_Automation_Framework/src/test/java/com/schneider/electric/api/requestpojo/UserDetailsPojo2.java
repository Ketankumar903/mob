package com.schneider.electric.api.requestpojo;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class UserDetailsPojo2 {
	@SerializedName("userContext")
	@Expose
	private String userContext;
	@SerializedName("salutation")
	@Expose
	private String salutation;
	@SerializedName("firstName")
	@Expose
	private String firstName;
	@SerializedName("middleName")
	@Expose
	private String middleName;
	@SerializedName("lastName")
	@Expose
	private String lastName;
	@SerializedName("countryCode")
	@Expose
	private String countryCode;
	@SerializedName("email")
	@Expose
	private String email;
	@SerializedName("password")
	@Expose
	private String password;
	@SerializedName("mobilePhone")
	@Expose
	private String mobilePhone;
	@SerializedName("languageCode")
	@Expose
	private String languageCode;
	@SerializedName("emailOptIn")
	@Expose
	private String emailOptIn;
	@SerializedName("street")
	@Expose
	private String street;
	@SerializedName("city")
	@Expose
	private String city;
	@SerializedName("zipCode")
	@Expose
	private String zipCode;
	@SerializedName("county")
	@Expose
	private String county;
	@SerializedName("pOBox")
	@Expose
	private String pOBox;
	@SerializedName("additionalAddress")
	@Expose
	private String additionalAddress;
	@SerializedName("suffix")
	@Expose
	private String suffix;
	@SerializedName("fax")
	@Expose
	private String fax;
	@SerializedName("accountId")
	@Expose
	private String accountId;
	@SerializedName("registrationSource")
	@Expose
	private String registrationSource;
	@SerializedName("companyDetailsPojo2")
	@Expose
	private CompanyDetailsPojo2 companyDetails;

	public String getUserContext() {
	return userContext;
	}

	public void setUserContext(String userContext) {
	this.userContext = userContext;
	}

	public String getSalutation() {
	return salutation;
	}

	public void setSalutation(String salutation) {
	this.salutation = salutation;
	}

	public String getFirstName() {
	return firstName;
	}

	public void setFirstName(String firstName) {
	this.firstName = firstName;
	}

	public String getMiddleName() {
	return middleName;
	}

	public void setMiddleName(String middleName) {
	this.middleName = middleName;
	}

	public String getLastName() {
	return lastName;
	}

	public void setLastName(String lastName) {
	this.lastName = lastName;
	}

	public String getCountryCode() {
	return countryCode;
	}

	public void setCountryCode(String countryCode) {
	this.countryCode = countryCode;
	}

	public String getEmail() {
	return email;
	}

	public void setEmail(String email) {
	this.email = email;
	}

	public String getPassword() {
	return password;
	}

	public void setPassword(String password) {
	this.password = password;
	}

	public String getMobilePhone() {
	return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
	this.mobilePhone = mobilePhone;
	}

	public String getLanguageCode() {
	return languageCode;
	}

	public void setLanguageCode(String languageCode) {
	this.languageCode = languageCode;
	}

	public String getEmailOptIn() {
	return emailOptIn;
	}

	public void setEmailOptIn(String emailOptIn) {
	this.emailOptIn = emailOptIn;
	}

	public String getStreet() {
	return street;
	}

	public void setStreet(String street) {
	this.street = street;
	}

	public String getCity() {
	return city;
	}

	public void setCity(String city) {
	this.city = city;
	}

	public String getZipCode() {
	return zipCode;
	}

	public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
	}

	public String getCounty() {
	return county;
	}

	public void setCounty(String county) {
	this.county = county;
	}

	public String getPOBox() {
	return pOBox;
	}

	public void setPOBox(String pOBox) {
	this.pOBox = pOBox;
	}

	public String getAdditionalAddress() {
	return additionalAddress;
	}

	public void setAdditionalAddress(String additionalAddress) {
	this.additionalAddress = additionalAddress;
	}

	public String getSuffix() {
	return suffix;
	}

	public void setSuffix(String suffix) {
	this.suffix = suffix;
	}

	public String getFax() {
	return fax;
	}

	public void setFax(String fax) {
	this.fax = fax;
	}

	public String getAccountId() {
	return accountId;
	}

	public void setAccountId(String accountId) {
	this.accountId = accountId;
	}

	public String getRegistrationSource() {
	return registrationSource;
	}

	public void setRegistrationSource(String registrationSource) {
	this.registrationSource = registrationSource;
	}

	public CompanyDetailsPojo2 getCompanyDetails() {
	return companyDetails;
	}

	public void setCompanyDetails(CompanyDetailsPojo2 companyDetails) {
	this.companyDetails = companyDetails;
	}

}
