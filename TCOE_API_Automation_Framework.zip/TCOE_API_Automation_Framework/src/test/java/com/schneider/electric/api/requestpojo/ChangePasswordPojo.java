package com.schneider.electric.api.requestpojo;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class ChangePasswordPojo {
	
	@SerializedName("oldPassword")
	@Expose
	private String oldPassword;
	@SerializedName("newPassword")
	@Expose
	private String newPassword;
	@SerializedName("profileLastUpdateSource")
	@Expose
	private String profileLastUpdateSource;

	public String getOldPassword() {
	return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
	this.oldPassword = oldPassword;
	}

	public String getNewPassword() {
	return newPassword;
	}

	public void setNewPassword(String newPassword) {
	this.newPassword = newPassword;
	}

	public String getProfileLastUpdateSource() {
	return profileLastUpdateSource;
	}

	public void setProfileLastUpdateSource(String profileLastUpdateSource) {
	this.profileLastUpdateSource = profileLastUpdateSource;
	}

	
	

}
