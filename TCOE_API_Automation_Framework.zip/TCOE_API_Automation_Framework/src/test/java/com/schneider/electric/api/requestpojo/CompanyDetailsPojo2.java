package com.schneider.electric.api.requestpojo;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class CompanyDetailsPojo2 {
	@SerializedName("currency")
	@Expose
	private String currency;
	@SerializedName("companyName")
	@Expose
	private String companyName;
	@SerializedName("companyStreet")
	@Expose
	private String companyStreet;
	@SerializedName("companyCity")
	@Expose
	private String companyCity;
	@SerializedName("companyZipCode")
	@Expose
	private String companyZipCode;
	@SerializedName("companyPOBox")
	@Expose
	private String companyPOBox;
	@SerializedName("companyCounty")
	@Expose
	private String companyCounty;
	@SerializedName("companyCountryCode")
	@Expose
	private String companyCountryCode;
	@SerializedName("companyAdditionalAddress")
	@Expose
	private String companyAdditionalAddress;
	@SerializedName("companyWebsite")
	@Expose
	private String companyWebsite;
	@SerializedName("classLevel1")
	@Expose
	private String classLevel1;
	@SerializedName("classLevel2")
	@Expose
	private String classLevel2;
	@SerializedName("marketServed")
	@Expose
	private String marketServed;
	@SerializedName("employeeSize")
	@Expose
	private String employeeSize;
	@SerializedName("department")
	@Expose
	private String department;
	@SerializedName("headquarter")
	@Expose
	private String headquarter;
	@SerializedName("annualRevenue")
	@Expose
	private String annualRevenue;
	@SerializedName("taxIdentificationNumber")
	@Expose
	private String taxIdentificationNumber;
	@SerializedName("jobTitle")
	@Expose
	private String jobTitle;
	@SerializedName("jobFunction")
	@Expose
	private String jobFunction;
	@SerializedName("jobDescription")
	@Expose
	private String jobDescription;
	@SerializedName("workPhone")
	@Expose
	private String workPhone;

	public String getCurrency() {
	return currency;
	}

	public void setCurrency(String currency) {
	this.currency = currency;
	}

	public String getCompanyName() {
	return companyName;
	}

	public void setCompanyName(String companyName) {
	this.companyName = companyName;
	}

	public String getCompanyStreet() {
	return companyStreet;
	}

	public void setCompanyStreet(String companyStreet) {
	this.companyStreet = companyStreet;
	}

	public String getCompanyCity() {
	return companyCity;
	}

	public void setCompanyCity(String companyCity) {
	this.companyCity = companyCity;
	}

	public String getCompanyZipCode() {
	return companyZipCode;
	}

	public void setCompanyZipCode(String companyZipCode) {
	this.companyZipCode = companyZipCode;
	}

	public String getCompanyPOBox() {
	return companyPOBox;
	}

	public void setCompanyPOBox(String companyPOBox) {
	this.companyPOBox = companyPOBox;
	}

	public String getCompanyCounty() {
	return companyCounty;
	}

	public void setCompanyCounty(String companyCounty) {
	this.companyCounty = companyCounty;
	}

	public String getCompanyCountryCode() {
	return companyCountryCode;
	}

	public void setCompanyCountryCode(String companyCountryCode) {
	this.companyCountryCode = companyCountryCode;
	}

	public String getCompanyAdditionalAddress() {
	return companyAdditionalAddress;
	}

	public void setCompanyAdditionalAddress(String companyAdditionalAddress) {
	this.companyAdditionalAddress = companyAdditionalAddress;
	}

	public String getCompanyWebsite() {
	return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
	this.companyWebsite = companyWebsite;
	}

	public String getClassLevel1() {
	return classLevel1;
	}

	public void setClassLevel1(String classLevel1) {
	this.classLevel1 = classLevel1;
	}

	public String getClassLevel2() {
	return classLevel2;
	}

	public void setClassLevel2(String classLevel2) {
	this.classLevel2 = classLevel2;
	}

	public String getMarketServed() {
	return marketServed;
	}

	public void setMarketServed(String marketServed) {
	this.marketServed = marketServed;
	}

	public String getEmployeeSize() {
	return employeeSize;
	}

	public void setEmployeeSize(String employeeSize) {
	this.employeeSize = employeeSize;
	}

	public String getDepartment() {
	return department;
	}

	public void setDepartment(String department) {
	this.department = department;
	}

	public String getHeadquarter() {
	return headquarter;
	}

	public void setHeadquarter(String headquarter) {
	this.headquarter = headquarter;
	}

	public String getAnnualRevenue() {
	return annualRevenue;
	}

	public void setAnnualRevenue(String annualRevenue) {
	this.annualRevenue = annualRevenue;
	}

	public String getTaxIdentificationNumber() {
	return taxIdentificationNumber;
	}

	public void setTaxIdentificationNumber(String taxIdentificationNumber) {
	this.taxIdentificationNumber = taxIdentificationNumber;
	}

	public String getJobTitle() {
	return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
	this.jobTitle = jobTitle;
	}

	public String getJobFunction() {
	return jobFunction;
	}

	public void setJobFunction(String jobFunction) {
	this.jobFunction = jobFunction;
	}

	public String getJobDescription() {
	return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
	this.jobDescription = jobDescription;
	}

	public String getWorkPhone() {
	return workPhone;
	}

	public void setWorkPhone(String workPhone) {
	this.workPhone = workPhone;
	}


}
