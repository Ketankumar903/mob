package com.schneider.electric.api.requestpojo;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UpdateUserProfilePojo {

@SerializedName("salutation")
@Expose
private String salutation;
@SerializedName("firstName")
@Expose
private String firstName;
@SerializedName("middleName")
@Expose
private String middleName;
@SerializedName("lastName")
@Expose
private String lastName;
@SerializedName("countryCode")
@Expose
private String countryCode;
@SerializedName("email")
@Expose
private String email;
@SerializedName("mobilePhone")
@Expose
private String mobilePhone;
@SerializedName("languageCode")
@Expose
private String languageCode;
@SerializedName("emailOptIn")
@Expose
private String emailOptIn;
@SerializedName("aboutMe")
@Expose
private String aboutMe;
@SerializedName("street")
@Expose
private String street;
@SerializedName("city")
@Expose
private String city;
@SerializedName("zipCode")
@Expose
private String zipCode;
@SerializedName("stateOrProvinceCode")
@Expose
private String stateOrProvinceCode;
@SerializedName("county")
@Expose
private String county;
@SerializedName("pOBox")
@Expose
private String pOBox;
@SerializedName("additionalAddress")
@Expose
private String additionalAddress;
@SerializedName("suffix")
@Expose
private String suffix;
@SerializedName("fax")
@Expose
private String fax;
@SerializedName("profileLastUpdateSource")
@Expose
private String profileLastUpdateSource;
@SerializedName("currency")
@Expose
private String currency;
@SerializedName("companyName")
@Expose
private String companyName;
@SerializedName("companyStreet")
@Expose
private String companyStreet;
@SerializedName("companyCity")
@Expose
private String companyCity;
@SerializedName("companyZipCode")
@Expose
private String companyZipCode;
@SerializedName("companyStateOrProvinceCode")
@Expose
private String companyStateOrProvinceCode;
@SerializedName("companyPOBox")
@Expose
private String companyPOBox;
@SerializedName("companyCounty")
@Expose
private String companyCounty;
@SerializedName("companyCountryCode")
@Expose
private String companyCountryCode;
@SerializedName("companyAdditionalAddress")
@Expose
private String companyAdditionalAddress;
@SerializedName("companyWebsite")
@Expose
private String companyWebsite;
@SerializedName("classLevel1")
@Expose
private String classLevel1;
@SerializedName("classLevel2")
@Expose
private String classLevel2;
@SerializedName("marketSegment")
@Expose
private String marketSegment;
@SerializedName("marketSubSegment")
@Expose
private String marketSubSegment;
@SerializedName("marketServed")
@Expose
private String marketServed;
@SerializedName("employeeSize")
@Expose
private String employeeSize;
@SerializedName("department")
@Expose
private String department;
@SerializedName("headquarter")
@Expose
private String headquarter;
@SerializedName("annualRevenue")
@Expose
private String annualRevenue;
@SerializedName("taxIdentificationNumber")
@Expose
private String taxIdentificationNumber;
@SerializedName("jobTitle")
@Expose
private String jobTitle;
@SerializedName("jobFunction")
@Expose
private String jobFunction;
@SerializedName("jobDescription")
@Expose
private String jobDescription;

@SerializedName("workPhone")
@Expose
private String workPhone;


public String getSalutation() {
return salutation;
}

public void setSalutation(String salutation) {
this.salutation = salutation;
}

public String getFirstName() {
return firstName;
}

public void setFirstName(String firstName) {
this.firstName = firstName;
}

public String getMiddleName() {
return middleName;
}

public void setMiddleName(String middleName) {
this.middleName = middleName;
}

public String getLastName() {
return lastName;
}

public void setLastName(String lastName) {
this.lastName = lastName;
}

public String getCountryCode() {
return countryCode;
}

public void setCountryCode(String countryCode) {
this.countryCode = countryCode;
}

public String getEmail() {
return email;
}

public void setEmail(String email) {
this.email = email;
}

public String getMobilePhone() {
return mobilePhone;
}

public void setMobilePhone(String mobilePhone) {
this.mobilePhone = mobilePhone;
}

public String getLanguageCode() {
return languageCode;
}

public void setLanguageCode(String languageCode) {
this.languageCode = languageCode;
}

public String getEmailOptIn() {
return emailOptIn;
}

public void setEmailOptIn(String emailOptIn) {
this.emailOptIn = emailOptIn;
}

public String getAboutMe() {
return aboutMe;
}

public void setAboutMe(String aboutMe) {
this.aboutMe = aboutMe;
}

public String getStreet() {
return street;
}

public void setStreet(String street) {
this.street = street;
}

public String getCity() {
return city;
}

public void setCity(String city) {
this.city = city;
}

public String getZipCode() {
return zipCode;
}

public void setZipCode(String zipCode) {
this.zipCode = zipCode;
}

public String getStateOrProvinceCode() {
return stateOrProvinceCode;
}

public void setStateOrProvinceCode(String stateOrProvinceCode) {
this.stateOrProvinceCode = stateOrProvinceCode;
}

public String getCounty() {
return county;
}

public void setCounty(String county) {
this.county = county;
}

public String getPOBox() {
return pOBox;
}

public void setPOBox(String pOBox) {
this.pOBox = pOBox;
}

public String getAdditionalAddress() {
return additionalAddress;
}

public void setAdditionalAddress(String additionalAddress) {
this.additionalAddress = additionalAddress;
}

public String getSuffix() {
return suffix;
}

public void setSuffix(String suffix) {
this.suffix = suffix;
}

public String getFax() {
return fax;
}

public void setFax(String fax) {
this.fax = fax;
}

public String getProfileLastUpdateSource() {
return profileLastUpdateSource;
}

public void setProfileLastUpdateSource(String profileLastUpdateSource) {
this.profileLastUpdateSource = profileLastUpdateSource;
}

public String getCurrency() {
return currency;
}

public void setCurrency(String currency) {
this.currency = currency;
}

public String getCompanyName() {
return companyName;
}

public void setCompanyName(String companyName) {
this.companyName = companyName;
}

public String getCompanyStreet() {
return companyStreet;
}

public void setCompanyStreet(String companyStreet) {
this.companyStreet = companyStreet;
}

public String getCompanyCity() {
return companyCity;
}

public void setCompanyCity(String companyCity) {
this.companyCity = companyCity;
}

public String getCompanyZipCode() {
return companyZipCode;
}

public void setCompanyZipCode(String companyZipCode) {
this.companyZipCode = companyZipCode;
}

public String getCompanyStateOrProvinceCode() {
return companyStateOrProvinceCode;
}

public void setCompanyStateOrProvinceCode(String companyStateOrProvinceCode) {
this.companyStateOrProvinceCode = companyStateOrProvinceCode;
}

public String getCompanyPOBox() {
return companyPOBox;
}

public void setCompanyPOBox(String companyPOBox) {
this.companyPOBox = companyPOBox;
}

public String getCompanyCounty() {
return companyCounty;
}

public void setCompanyCounty(String companyCounty) {
this.companyCounty = companyCounty;
}

public String getCompanyCountryCode() {
return companyCountryCode;
}

public void setCompanyCountryCode(String companyCountryCode) {
this.companyCountryCode = companyCountryCode;
}

public String getCompanyAdditionalAddress() {
return companyAdditionalAddress;
}

public void setCompanyAdditionalAddress(String companyAdditionalAddress) {
this.companyAdditionalAddress = companyAdditionalAddress;
}

public String getCompanyWebsite() {
return companyWebsite;
}

public void setCompanyWebsite(String companyWebsite) {
this.companyWebsite = companyWebsite;
}

public String getClassLevel1() {
return classLevel1;
}

public void setClassLevel1(String classLevel1) {
this.classLevel1 = classLevel1;
}

public String getClassLevel2() {
return classLevel2;
}

public void setClassLevel2(String classLevel2) {
this.classLevel2 = classLevel2;
}

public String getMarketSegment() {
return marketSegment;
}

public void setMarketSegment(String marketSegment) {
this.marketSegment = marketSegment;
}

public String getMarketSubSegment() {
return marketSubSegment;
}

public void setMarketSubSegment(String marketSubSegment) {
this.marketSubSegment = marketSubSegment;
}

public String getMarketServed() {
return marketServed;
}

public void setMarketServed(String marketServed) {
this.marketServed = marketServed;
}

public String getEmployeeSize() {
return employeeSize;
}

public void setEmployeeSize(String employeeSize) {
this.employeeSize = employeeSize;
}

public String getDepartment() {
return department;
}

public void setDepartment(String department) {
this.department = department;
}

public String getHeadquarter() {
return headquarter;
}

public void setHeadquarter(String headquarter) {
this.headquarter = headquarter;
}

public String getAnnualRevenue() {
return annualRevenue;
}

public void setAnnualRevenue(String annualRevenue) {
this.annualRevenue = annualRevenue;
}

public String getTaxIdentificationNumber() {
return taxIdentificationNumber;
}

public void setTaxIdentificationNumber(String taxIdentificationNumber) {
this.taxIdentificationNumber = taxIdentificationNumber;
}

public String getJobTitle() {
return jobTitle;
}

public void setJobTitle(String jobTitle) {
this.jobTitle = jobTitle;
}

public String getJobFunction() {
return jobFunction;
}

public void setJobFunction(String jobFunction) {
this.jobFunction = jobFunction;
}

public String getJobDescription() {
return jobDescription;
}

public void setJobDescription(String jobDescription) {
this.jobDescription = jobDescription;
}

public String getWorkPhone() {
	return workPhone;
}

public void setWorkPhone(String workPhone) {
	this.workPhone = workPhone;
}

}