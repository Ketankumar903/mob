package com.schneider.electric.api.baseurls;

public class BaseURLs {

}
