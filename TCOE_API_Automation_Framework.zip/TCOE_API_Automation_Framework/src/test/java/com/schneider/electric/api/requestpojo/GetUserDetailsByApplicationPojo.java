package com.schneider.electric.api.requestpojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetUserDetailsByApplicationPojo {

	@SerializedName("appHash")
	@Expose
	private String appHash;
	
	@SerializedName("email")
	@Expose
	private String email;

	public String getAppHash() {
		return appHash;
	}

	public void setAppHash(String appHash) {
		this.appHash = appHash;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	
}
