package com.schneider.electric.api.requestpojo;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PasswordRecoveryPojo {
	
	@SerializedName("email")
	@Expose
	private String email;
	@SerializedName("profileLastUpdateSource")
	@Expose
	private String profileLastUpdateSource;

	public String getEmail() {
	return email;
	}

	public void setEmail(String email) {
	this.email = email;
	}

	public String getProfileLastUpdateSource() {
	return profileLastUpdateSource;
	}

	public void setProfileLastUpdateSource(String profileLastUpdateSource) {
	this.profileLastUpdateSource = profileLastUpdateSource;
	}

}
