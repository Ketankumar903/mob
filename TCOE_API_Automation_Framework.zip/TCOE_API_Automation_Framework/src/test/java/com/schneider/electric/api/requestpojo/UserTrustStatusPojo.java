package com.schneider.electric.api.requestpojo;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class UserTrustStatusPojo {
	@SerializedName("trustedAdminId")
	@Expose
	private String trustedAdminId;
	@SerializedName("newTrustedStatus")
	@Expose
	private String newTrustedStatus;
	@SerializedName("profileUpdateSource")
	@Expose
	private String profileUpdateSource;
	@SerializedName("rejectionReason")
	@Expose
	private String rejectionReason;
	@SerializedName("rejectionComments")
	@Expose
	private String rejectionComments;

	public String getTrustedAdminId() {
	return trustedAdminId;
	}

	public void setTrustedAdminId(String trustedAdminId) {
	this.trustedAdminId = trustedAdminId;
	}

	public String getNewTrustedStatus() {
	return newTrustedStatus;
	}

	public void setNewTrustedStatus(String newTrustedStatus) {
	this.newTrustedStatus = newTrustedStatus;
	}

	public String getProfileUpdateSource() {
	return profileUpdateSource;
	}

	public void setProfileUpdateSource(String profileUpdateSource) {
	this.profileUpdateSource = profileUpdateSource;
	}

	public String getRejectionReason() {
	return rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
	this.rejectionReason = rejectionReason;
	}

	public String getRejectionComments() {
	return rejectionComments;
	}

	public void setRejectionComments(String rejectionComments) {
	this.rejectionComments = rejectionComments;
	}


}
