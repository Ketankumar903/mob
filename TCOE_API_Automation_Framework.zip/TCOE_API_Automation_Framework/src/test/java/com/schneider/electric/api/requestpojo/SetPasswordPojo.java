package com.schneider.electric.api.requestpojo;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class SetPasswordPojo {
	@SerializedName("userId")
	@Expose
	private String userId;
	@SerializedName("federatedId")
	@Expose
	private String federatedId;
	@SerializedName("password")
	@Expose
	private String password;
	@SerializedName("profileLastUpdateSource")
	@Expose
	private String profileLastUpdateSource;
	@SerializedName("token")
	@Expose
	private String token;

	public String getUserId() {
	return userId;
	}

	public void setUserId(String userId) {
	this.userId = userId;
	}

	public String getFederatedId() {
	return federatedId;
	}

	public void setFederatedId(String federatedId) {
	this.federatedId = federatedId;
	}

	public String getPassword() {
	return password;
	}

	public void setPassword(String password) {
	this.password = password;
	}

	public String getProfileLastUpdateSource() {
	return profileLastUpdateSource;
	}

	public void setProfileLastUpdateSource(String profileLastUpdateSource) {
	this.profileLastUpdateSource = profileLastUpdateSource;
	}

	public String getToken() {
	return token;
	}

	public void setToken(String token) {
	this.token = token;
	}
}
