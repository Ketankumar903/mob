package com.schneider.electric.api.requestpojo;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class UpdateUserAILPojo {

	@SerializedName("aclType")
	@Expose
	private String aclType;
	@SerializedName("acl")
	@Expose
	private String acl;
	@SerializedName("operation")
	@Expose
	private String operation;
	@SerializedName("profileLastUpdateSource")
	@Expose
	private String profileLastUpdateSource;

	public String getAclType() {
	return aclType;
	}

	public void setAclType(String aclType) {
	this.aclType = aclType;
	}

	public String getAcl() {
	return acl;
	}

	public void setAcl(String acl) {
	this.acl = acl;
	}

	public String getOperation() {
	return operation;
	}

	public void setOperation(String operation) {
	this.operation = operation;
	}

	public String getProfileLastUpdateSource() {
	return profileLastUpdateSource;
	}

	public void setProfileLastUpdateSource(String profileLastUpdateSource) {
	this.profileLastUpdateSource = profileLastUpdateSource;
	}
	
	
}
