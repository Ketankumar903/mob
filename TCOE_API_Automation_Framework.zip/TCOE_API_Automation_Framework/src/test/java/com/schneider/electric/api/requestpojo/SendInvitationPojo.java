package com.schneider.electric.api.requestpojo;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class SendInvitationPojo {
	
	@SerializedName("email")
	@Expose
	private String email;
	@SerializedName("invitationId")
	@Expose
	private String invitationId;
	@SerializedName("redirectUrl")
	@Expose
	private String redirectUrl;

	public String getEmail() {
	return email;
	}

	public void setEmail(String email) {
	this.email = email;
	}

	public String getInvitationId() {
	return invitationId;
	}

	public void setInvitationId(String invitationId) {
	this.invitationId = invitationId;
	}

	public String getRedirectUrl() {
	return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
	this.redirectUrl = redirectUrl;
	}


}
