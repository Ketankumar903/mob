package com.schneider.electric.base;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.schneider.electric.utility.ExtentManager;
import com.schneider.electric.utility.Xls_Reader;


public class Base {
	
	///Intializaing Suite object at Global level
	 public static Xls_Reader suiteXls=null;
	 public static Xls_Reader suiteBxls=null;
	//Intilaizing Extent Report object for Starting Writing Report During Runtime at global level(Class level)
	public static ExtentReports report;
	//Initializing Extent Test Object for capturing all the steps into Extent report and Screenshots at global level(Class level)
	public static ExtentTest test;
	public static WebDriver driver=null;
	public static WebElement element=null;
	public static Properties OR=null;
	public static Properties CONFIG=null;
	public static Properties HarakiriMailPage=null;
	public static Properties gmailPage=null;
	public Base()
	{ 
		if(driver==null){
			//Configuring OR Properties File	
			OR=new Properties();
			CONFIG=new Properties();
			HarakiriMailPage=new Properties();
			gmailPage=new Properties();
			FileInputStream fs=null;
			try {
				//Load Config Properties file
				fs=new FileInputStream(System.getProperty("user.dir")+"\\Config.properties");
				CONFIG.load(fs);
				fs=new FileInputStream(System.getProperty("user.dir")+"\\Config\\HarakiriMailPage.properties");
				HarakiriMailPage.load(fs);
				fs=new FileInputStream(System.getProperty("user.dir")+"\\Config\\GMailPage.properties");
                gmailPage.load(fs);
                fs=new FileInputStream(System.getProperty("user.dir")+"\\Config\\OR.properties");
                OR.load(fs);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return ;
			}
			finally
			{
				try {
					if(fs!=null)
					fs.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		//Using Reflection Concept to get the instance of Extent Manager Class	
		report=ExtentManager.getInstance();
		//initialize excel files
		suiteXls=new Xls_Reader(System.getProperty("user.dir")+"\\xls\\Suite.xlsx");
		//suiteAxls=new Xls_Reader(System.getProperty("user.dir")+"\\xls\\A Suite.xlsx");
		suiteBxls=new Xls_Reader(System.getProperty("user.dir")+"\\xls\\B Suite.xlsx");
		}
	}
	
	/***
	 * Method Name: openBrowser
	 * @param: browser
	 * @type: String
	 * @Description:This method is used to Open Browser based on Browser Type set in Config File,Maximize the browser,apply imlicitly Wait
	 * @author SESA443020(Azharuddin Khan)
	 */
	public static void openBrowser(String browser)
	{
		try{
       if(browser.equals("Chrome")){
			 System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\Drivers\\chromedriver_new.exe");
		     driver=new ChromeDriver();
			  driver.manage().window().maximize();
			  driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
			  driver.manage().deleteAllCookies();
			  test.log(LogStatus.INFO,CONFIG.getProperty("Browser")+" Browser Has Been Launched.");
			 
		}
		
		}
		 catch(Exception e)
		{
		       //Write Exception into Extent Report if it fails
			   test.log(LogStatus.FAIL, e.getMessage());
			   //Write Exception into Log file if it fails
			  // test.log(LogStatus.FAIL,e.getMessage());
			   //test.log(LogStatus.INFO,CONFIG.getProperty("Browser")+" Browser Has Not Been Launched.");
		}
	}	
	
	/***
	 * Method Name: closeBrowser
	 * @param:N/A
	 * @type: String
	 * @Description:This method is used to close the current focused browser window
	 * @author SESA443020(Azharuddin Khan)
	 */
	public static void closeBrowser()
	{   
		driver.close();
		test.log(LogStatus.INFO, "Browser has been closed.");
	}
	
	
	
	public static void turnOnImplicitWaits()
	{
		 driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	}
	
	public static void turnOffImplicitWaits()
	{
		 driver.manage().timeouts().implicitlyWait(0,TimeUnit.SECONDS);
	}

}
